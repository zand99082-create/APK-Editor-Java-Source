.class public final Luk/co/chrisjenx/calligraphy/R$layout;
.super Ljava/lang/Object;


# static fields
.field public static final activity_main_just_for_test:I = 0x7f020000


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
