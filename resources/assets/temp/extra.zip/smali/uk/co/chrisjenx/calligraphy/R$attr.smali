.class public final Luk/co/chrisjenx/calligraphy/R$attr;
.super Ljava/lang/Object;


# static fields
.field public static final fontPath:I = 0x7f010000


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
