.class public final Luk/co/chrisjenx/calligraphy/R$id;
.super Ljava/lang/Object;


# static fields
.field public static final calligraphy_tag_id:I = 0x7f030000


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
