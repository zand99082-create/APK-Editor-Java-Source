.class synthetic Luk/co/chrisjenx/calligraphy/CalligraphyFactory$1;
.super Ljava/lang/Object;
